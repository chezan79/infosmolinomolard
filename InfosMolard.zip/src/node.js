mkdir backend
cd backend
npm init -y
npm install express mongoose cors
